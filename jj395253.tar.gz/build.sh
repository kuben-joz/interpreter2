#!/bin/bash
rm -rf src/csrc/build
mkdir src/csrc/build
cmake -DCMAKE_BUILD_TYPE=Release -S src/csrc -B src/csrc/build
cmake --build src/csrc/build
make