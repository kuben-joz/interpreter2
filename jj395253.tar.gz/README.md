# Kompilator Latte

## Ogólny opis

Rozwiązanie dzieli się na moduły:

- `haskellsrc` to frontend
- `csrc`
  - `treeparse`, czytanie pretty print AST z frontend
  - `ir_builder`, wczytuje AST do reprezentacji biblitoeki llvm
  - `printer`, wypisuje wynik w llvm-ir
    - Jeśli chce Pani trochę ładniejszy wynik to na końcu `main()` w `main.cpp` można oddkomentować `// module->dump();` co wypiszę to samo drzewo na stderr z lepsyzmi nazwami rejestrów i bloków oraz informacjami w stylu `; preds blk_body, blk_cond`
  - `passes` to optymalizacje
    - `gcse`
    - `init_pass` dodaje ret void na koncu funkcji void i tym podobne
    - `liveness` nie wykorzystane
    - `mem2reg` zmiana alloca na rejestry i phi
    - `tree_fold`/`tree_trim` upraszcanie CFG
    - `val_prop` propagacja stałych i rzeczy w stylu `%ptr1 == %ptr1` -> `true`
  - `trees`
    - `cfg`
    - `dom_tree`, razem z iterated dominance frontier

## Budowanie

Mamy opcje:

- make
- make clean

Powinny teraz działać bez `build.sh` ale zostawiam jeśli byłyby problemy 

## Biliboteki
- LLVM-14 z ktorej wykorzystuje
  - Reprezentacje linked list
  - Visitor model
  - Instrukcje find uses która daje miejsca gdzie dany rejestr SSA jest wykorzystany 

