module StaticAnalysis.Environment where

