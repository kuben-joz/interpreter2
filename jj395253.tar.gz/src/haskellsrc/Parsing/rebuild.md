# Built with

`bnfc -- functor -m macchiato.cf`

If something doesn't work here just run
`python build-parser.py clean`
`python build-parser`

have to add Parsing package prefix to a few files that show errors